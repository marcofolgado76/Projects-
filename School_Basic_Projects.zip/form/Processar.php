<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Formulario Aluno</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid container-table" id="input" style="margin-top: 2%">
   <div class="vertical-center-row">
   <div class="row">
			<div class="col-md-4"></div>
    <?php
        $nome=$_POST['name'];
        $apelido=$_POST['apelido'];
        $idade=$_POST['idade'];
        $email=$_POST['email'];
        $sexo=$_POST['genero'];
        $turma=$_POST['turmas'];
        

        echo "<h1>Bom dia ".$nome." ".$apelido.", você tem ".$idade." anos ,é do sexo ".$sexo.".A sua turma é ".$turma." e o email  ".$email."</h1>"; 
    ?>
    </div>
    <br>
    </div>
</div>

</body>
</html>