<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Ficha3-Formulario Aluno</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid container-table" id="inserção" style="margin-top: 2%">
		<div class="vertical-center-row">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-8">
			<h1>Formulario Aluno</h1>
			<form action="processar.php" method="post">
				<div class="form-group">
					<label class="control-label">Nome- <input class="form-control" placeholder="Escreva o Seu nome" type="text" name="name" required></label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="form-group">
					<label class="control-label">Apelido- <input class="form-control" placeholder="Digite seu Apelido" type="text" name="apelido" required></label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="form-group">
					<label class="control-label">Idade- <input class="form-control" placeholder="Digite a sua Idade" type="number" name="idade" required></label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="form-group">
    				<label class="control-label">Email-<input class="form-control" placeholder="Digite seu E-mail" type="email"  name="email"  data-error="Preencha com e-mail correto." required></label>
    				<div class="help-block with-errors"></div>
  				</div>
				<div class="form-group">
					<label class="control-label">Gênero-
						<input type="radio" name="genero"  value="Feminino">Feminino
						<input type="radio" name="genero" value="Masculino" checked="checked">Masculino
					</label>
				</div>
				<div class="form-group">
					<label class="control-label">Turma-
						<select name="turmas">
							<option value="PSI1">PSI1</option>
							<option value="PSI2">PSI2</option>
							<option value="PSI3">PSI3</option>
						</select>
					</label>
				</div>
				<div class="form-group">
    				<button type="submit" class="btn btn-primary">Enviar</button>
  				</div>
			</form>
			</div>
		</div>
	</div>
</div>

</body>

</html>