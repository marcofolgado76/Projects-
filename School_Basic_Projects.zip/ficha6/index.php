<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
   <div class="container-fluid">
    <div class="row">
    <div class="col-md-4"/>
    <form action="resultado.php" method="get">
      <label>Mini Google</label><br>
      <input type="text" name="pesquisa" placeholder="O melhor motor de busca de sempre">
      <input type="submit" name="submeter" value="Pesquisar">
    </form>
    </div>
    </div>
    </div>
  </body>
</html>