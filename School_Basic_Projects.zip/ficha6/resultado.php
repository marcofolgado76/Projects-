<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    $busca = array("marco", "marco", "ricardo", "ricardo", "Edgar", "ricardo", "manuel","joaquim", "josefina");
         if (isset($_GET['pesquisa'])){
        $pesquisa=$_GET['pesquisa'];
        $pesquisa=strtolower($pesquisa);
        $tmp = array_count_values($busca);
        $cnt = $tmp[$pesquisa];
        echo "foram encontrados " . $cnt . " resultados para " . $pesquisa;
      }
     ?>
     <br>
     <a href="https://www.google.pt/#q=<?php echo $pesquisa ?>">Pesquisa melhor no Google </a>
     <br>
     <a href="https://www.facebook.com/search/top/?q=<?php echo $pesquisa ?>&init=mag_glass&tas=0.6407594480076713&search_first_focus=1487674261802">Pesquisa os teus amigos no Facebook!</a>
  </body>
</html>