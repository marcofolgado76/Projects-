<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/js/materialize.min.js"></script>
          
    <title></title>
  </head>
  <body>
    <?php
    session_start();
    ob_start();
    include "funcoes.php";
      if (isset($_SESSION['log'])) {
        ?>
        <h1 style="color: #00B285; text-align: center;" >Acesso Restrito!</h1>
        <h2 style="color: #00B285; text-align: center;">Seja muito Bem Vindo <?php } echo $_SESSION['user']?> !!</h2>
    <form method="post" action="funcoes.php">
      <p>

       <nav>
          <div class="nav-wrapper">
            <ul class="left hide-on-med-and-down">
              
              <li><a href="backoffice.php">Inicio</a></li>
              <li><a href="exer.php">Exercicios</a></li>
            
            </ul>
          </div>
        </nav>
      <script type="text/javascript" language="javascript">
                $( document ).ready(function(){
                $(".button-collapse").sideNav();
                $('.carousel').carousel();
                $('.carousel-slider').slider({full_width: true});
            });

        </script>
        <div class="carousel carousel-slider">
            <a class="carousel-item" href="#one!"><img src="https://scotch.io/wp-content/uploads/2015/01/getting-started-materialize-css-framework.png"></a>
            <a class="carousel-item" href="#two!"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/PHP-logo.svg/1200px-PHP-logo.svg.png"></a>
            <a class="carousel-item" href="#three!"><img src="http://www.chico-esperto.com/wp-content/uploads/2015/02/css_cascading_style_sheet.jpg"></a>
            <a class="carousel-item" href="#four!"><img src="http://www.davidchc.com.br/wp-content/uploads/2016/06/495484_385c_3.jpg"></a>
        </div>
        
          <button class="btn waves-effect waves-light" type="submit" name="terminar" >
           <i class="material-icons right">Terminar Sessão </i>
         </button>
        

      
      </p>
    </form>
  <script>
     
  </script>
  </body>
</html>
