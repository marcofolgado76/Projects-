<?php
  if (isset($_POST['login'])) {
    if ($_POST['user']!=""&&$_POST['pw']!="") {
      session_start();
      ob_start();
      iniciarsessao($_POST['user'], $_POST['pw']);
    }
    else {
      header("location:login.php");
    }
  }
  function iniciarsessao($user,$pw){
    if (trim($user)=="admin"&&$pw=="123") {
      $_SESSION['user']=$user;
      $_SESSION['log']=true;
      header("location:backoffice.php");
    }
    else {
      header("location:login.php");
    }
  }
  
  if (isset($_POST['terminar'])) {
    session_start();
    ob_start();
    terminarSessao();
    header("location:login.php");
  }
  function terminarSessao(){
    if (isset($_POST['terminar'])) {
      unset($_SESSION['utilizador']);
      unset($_SESSION['logado']);
      session_destroy();
    }
  }

  function geraSenha($tamanho)
  {
    $peq = 'abcdefghijklmnopqrstuvwxyz';
    $grand = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $num = '1234567890';
    $simb = '!@#$%*-';
    $retorno = '';
    $senha = '';
    $senha .= $peq;
    $senha .= $grand;
    $senha .= $num;
    $senha .= $simb;
    $len = strlen($senha);
    
    for ($i = 1; $i <= $tamanho; $i++) 
    {
      $rand = mt_rand(1, $len);
      $retorno .= $senha[$rand-1];
    }
    return $retorno;
  }

  function saudacao()
  {
    $hora = date('H');
    if ( $hora >= 5 && $hora <= 11 ) echo "Bom dia";
    else if ( $hora >= 12 && $hora <= 18 ) echo "Boa tarde";
    else if ( $hora >= 19 || $hora <= 4 ) echo "Boa noite";
  }

  function numeros($tamanho=20)
  {
    if (isset($_POST['numenv'])) 
    {
      if ($_POST['num1'] > $_POST['num2']) {
        echo "<font color=\"#FF0000\"><b>Impossivel";
      }
      else
      {
        if ($_POST['num1'] !="" && $_POST['num2'] !="")  
        {
          $num1=$_POST['num1'];
          $num2=$_POST['num2'];
          for ($i=0; $i < $tamanho; $i++) 
          { 
            echo "<b>".(mt_rand($num1,$num2)). ", ";
          }
        }
        else
          echo "<font color=\"#FF0000\"><b>Preencha as caixas";
      }
    }
    
  }
?>