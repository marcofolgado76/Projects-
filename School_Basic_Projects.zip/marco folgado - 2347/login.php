<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
</head>
<body>
<h1 style="color: #00B285; text-align: center;">Formulário de Autenticação</h1>
  <form method="post" action="funcoes.php">
      <div class="row">
      <div class="valign-wrapper">
      <form class="col s12">
      <div class="row">
        <div class="col s6">
     <p>
        <label for="user">Utilizador</label>
        <input type="text" name="user">

        <label for="pw">Palavra-Chave</label>
        <input type="password" name="pw">

         <button class="btn waves-effect waves-light" type="submit" name="login" ">
           <i class="material-icons right">Submeter</i>
         </button>
      </p>
      </div>
      </div>
      </div>
      </form>
      </div>
    </form>

 
  </body>
</html>