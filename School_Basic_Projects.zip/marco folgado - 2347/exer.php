<?php
  include "funcoes.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js"></script>
   <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/js/materialize.min.js"></script>
</head>
<body>
      <div class="row">
      <div class="valign-wrapper">
      <div class="col s12">
      <div class="row">
      <div class="col s6">
        <h1>Exercicio 1</h1>
        <form action="<?php echo $_SERVER ['PHP_SELF'];?>" method="post">
          <label for="numero">Numeros: </label><input type='text' name='numero'/></p>
          <button class="btn waves-effect waves-light" type="submit" name="enviarNum" ">
           <i class="material-icons right">Enviar</i>
         </button>
          <p>
            <?php
               if (isset($_POST['enviarNum'])) 
              {           
                if ($_POST['numero'] != "") 
                {
                    $numeros=$_POST['numero'];
                    $array= explode(',', $numeros);
                    echo "<br> O numero maximo é: ".max($array)." e o numero minimo é: ".min($array);
                 }      
                else echo "Insira numero separados por virgulas";
              }
            ?>
        </form>
      </div>
      </div>
      </div>
      </div>
      </div>
<br>
      <div class="row">
      <div class="valign-wrapper">
      <div class="col s12">
      <div class="row">
      <div class="col s6">
        <h1>Exercicio 2</h1>
          <?php
            $geraSenha = geraSenha(8);
            echo 'A senha é '.$geraSenha;
          ?> 
      </div>
      </div>
      </div>
      </div>
      </div>

      <div class="row">
      <div class="valign-wrapper">
      <div class="col s12">
      <div class="row">
      <div class="col s6">
        <h1>Exercicio 3</h1>
          <?php
            date_default_timezone_set("europe/Lisbon");
            echo date("l jS \of F Y H:i:s A") . "<br>";
            saudacao();
          ?> 
      </div>
      </div>
      </div>
      </div>
      </div>

      <div class="row">
      <div class="valign-wrapper">
      <div class="col s12">
      <div class="row">
      <div class="col s6">
        <h1>Exercicio 4</h1>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
          <input type="number" name="num1">
          <input type="number" name="num2">
          <button class="btn waves-effect waves-light" type="submit" name="numenv" ">
           <i class="material-icons right">Enviar</i>
         </button>
        </form>
          <?php
            numeros();
          ?> 
      </div>
      </div>
      </div>
      </div>
      </div>
              
</body>
</html>