<?php
  session_start();
  ob_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Ficha de Revisões</title>
  </head>
  <body>
        <h3 class="center">Inicio de Sessão</h3>
    <form action="processa.php" method="post">
      <div class="row">
        <form class="col s12">
          <div class="row">
            <div class="input-field col s3">
            </div>
            <div class="input-field col s3">
<select name="login">
  <option value="Lucas">Lucas</option>
  <option value="Pedro">Pedro</option>
  <option value="Luis">Luis</option>
</select>
<br>
            </div>
            <div class="input-field col s3">
            <label>Senha<input type="password" name="senha" <?php if (isset($_POST['senha'])) echo 'value = \'' . $_POST['senha'] . '\'' ?>></label>
            </div>
            <div class="input-field col s3">
            </div>
          </div>
          <div class="input-field col s5">
          </div>
      <div class="form-group">
        <br>
        <button type="submit" name="enviar">Iniciar Sessão</button>
      </div>
    </form>
  </body>
</html>