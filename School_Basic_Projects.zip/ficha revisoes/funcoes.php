<?php

  if (isset($_POST['enviar']))
  {
      if ($_POST['login']!=""&&$_POST['senha']!="")
      {
          session_start();
          ob_start();
          iniciarsessao($_POST['login'], $_POST['senha']);
      }
    else header("location:index5.php");
  }
  if (isset($_POST['terminar'])) {
    session_start();
    ob_start();
    terminarSessao();
    header("location:index5.php");
  }
  if (isset($_POST['voltar'])) {
    session_start();
    ob_start();
    header("location:restrito.php");
  }

  function iniciarsessao($user,$senha)
  {
    if (trim($user)=="admin"&&$senha=="123")
      {
          $_SESSION['login']=$user;
          $_SESSION['logado']=true;
          header("location:restrito.php");
      }
    else header("location:index5.php");
  }

  function terminarSessao(){
    if (isset($_POST['terminar'])) {
        unset($_SESSION['login']);
    unset($_SESSION['logado']);
    session_destroy();
    header('Location:index5.php');
    }
  }

  function exer34($tamanho=20)
    {
      if (isset($_POST['submit']))
      {
        if ($_POST['num1'] > $_POST['num2']) {
          echo "<font color=\"#FF0000\"><b>Impossivel";
        }
        else
        {
          if ($_POST['num1'] !="" && $_POST['num2'] !="")
          {
            $num1=$_POST['num1'];
            $num2=$_POST['num2'];
            for ($i=0; $i < $tamanho; $i++)
            {
              echo "<b>" ." (".(mt_rand($num1,$num2)). ") ";
            }
          }
          else
            echo "<font color=\"#FF0000\"><b>Preencha as caixas";
        }
      }

    }
?>
Fim da conversa de chat
