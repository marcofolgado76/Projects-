<?php
if (isset($_POST['enviar']))
	{
    	if ($_POST['login']!="" && $_POST['senha']!="")
    	{
      		session_start();
      		ob_start();
      		iniciarsessao($_POST['login'], $_POST['senha']);
    	}
    else header("location:index.php");
  }
  if (isset($_POST['terminar'])) {
   	session_start();
    ob_start();
    terminarSessao();
    header("location:index.php");
  }
  function iniciarsessao($user,$senha)
  {
    if (trim($user)=="pedro" && $senha=="123" || trim($user)=="joana"&& $senha=="456" || trim($user)=="ludovico"&& $senha=="321")
    	{
      		$_SESSION['login']=$user;
      		$_SESSION['logado']=true;
      		header("location:restrito.php");
    	}
    else header("location:index.php");
  }
function terminarSessao(){
  if (isset($_POST['terminar'])) {
      unset($_SESSION['login']);
  unset($_SESSION['logado']);
  session_destroy();
  header('Location:index.php');
  }
}
function calcularmedia($mat, $tic){
  $media=$mat*0.35+$tic*0.65;
  return $media;
}
  ?>