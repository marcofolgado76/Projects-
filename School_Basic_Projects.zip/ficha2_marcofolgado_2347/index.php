<!DOCTYPE html>
<html>
<head>
	<title>Autenticação</title>
</head>
<body style="text-align:center;">
        <h3 class="center">Inicio de Sessão</h3>
    	<form action="funcoes.php" method="post">
    	<input type="radio" name="login" value="pedro"> Pedro
    	<br>
	    <input type="radio" name="login" value="joana"> Joana
	    <br>
		<input type="radio" name="login" value="ludovico"> Ludovico
			
			<br>
			<br>
            <label>Senha<input type="password" name="senha" <?php if (isset($_POST['senha'])) echo 'value = \'' . $_POST['senha'] . '\'' ?>></label>

		<br>
        <button type="submit" name="enviar">Iniciar Sessão</button>
</form>

</body>
</html>