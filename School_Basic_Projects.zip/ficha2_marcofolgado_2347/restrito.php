<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Acesso restrito</title>
</head>
<body style="text-align:center;">
	 <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
		<h1>Bem Vindo <?php echo $_SESSION['login']?> !</h1>
       	<br>
	     <input type="number" placeholder="Matematica " name="mat" min="0" max="20" ></input>
	     <br>
	     <input type="number" placeholder="tic " name="tic" min="0" max="20" > </input>
	     <br>
	     <input type="submit" name="submeter"></input>
         <br>
         <div>
          <button type="submit" name="terminar">Terminar Sessão</button>
         </div>
     </form>
	<?php
	    if (isset($_POST['terminar'])) {
	      session_destroy();
	      header('location:index.php');
	    }

		if (isset($_POST['submeter'])) {
		if ($_POST['mat']>=0 && $_POST['mat']<=20 && $_POST['tic']>=0 && $_POST['tic']<=20) {
  		include "funcoes.php";
          $mat=$_POST['mat'];
          $tic=$_POST['tic'];
          $media=calcularmedia($mat, $tic);
          if ($media >= 10) {
          	?>
          	<div style="background-color:green;">
          	<?php
          	echo "O ". $_SESSION['login']." tem " . $mat . " a matemática e " . $tic . " a TIC, a sua média é ". $media ;
          	?>
          	</div>	
          	<?php
          }
          else 
          {
          	?>
          	<div style="background-color:red;">
          	<?php
          	echo "O ". $_SESSION['login']." tem " . $mat . " a matemática e " . $tic . " a TIC, a sua média é ". $media ;
          	?>
          	</div>	
          	<?php

          }
        }
        else {
          echo "Insira valores válidos (Nota de 0 a 20)";
        }
  	}
	?>
</body>
</html>