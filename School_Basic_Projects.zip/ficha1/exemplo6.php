<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
<?php 

	for ($i = 10; $i >= 1; $i--)
		{

	  		echo "O numero é:". $i . "<br>";

		}
 ?>
</body>
</html>