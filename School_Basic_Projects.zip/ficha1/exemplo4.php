<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
<?php 
	for ($i=10; $i >= 1 ; $i--) { 

	if ($i%2 == 0) {
		echo "O numero é:" . "<b><font color=\"#7CFC00\">" . $i . "</font></b>". "<br>";
	} else {
		echo "O numero é:" . "<b><font color=\"#FF0000\">" . $i . "</font></b>". "<br>";
	}
	
}

	
 ?>
</body>
</html>