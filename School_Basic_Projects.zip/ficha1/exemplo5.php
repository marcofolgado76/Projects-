<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
<?php 

	$nr = array(1,2,3,4,6,7,8,9,10);
$arrlength = count($nr);

for($i = 0; $i < $arrlength; $i++) {
    echo $nr[$i];
    echo "<br>";
    
  
}
echo "O maximo é:";
echo (max($nr) . "<br>");
 ?>
</body>
</html>