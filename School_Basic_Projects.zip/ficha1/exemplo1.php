<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
<?php 
	$nome = "Marco";
	$idade=16;
	echo "Ola " . $nome .  " tens " . $idade . " anos" ;
 ?>
</body>
</html>