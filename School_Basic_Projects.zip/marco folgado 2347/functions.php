<?php
function iniciarSessao($user, $pw){
  if ($user=="lucas"&&$pw==123 || $user=="pedro"&&$pw==456 || $user=="luis"&&$pw==321) {
    session_start();
    $_SESSION['user']=$user;
    $_SESSION['log']=true;
    return true;
  }
  else {
    return false;
  }
}
function calcularMedia($notaMat, $notaTic){
  $media=$notaMat*0.4+$notaTic*0.6;
  return $media;
}
?>
