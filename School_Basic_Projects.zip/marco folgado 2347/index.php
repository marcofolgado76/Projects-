<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Teste de Avaliação</title>
</head>
<body style="text-align:center; background-color:yellow">
  <?php
  session_start();
  if (isset($_SESSION['log'])&&$_SESSION['log']==true) {
    $utilizadorAtual=$_SESSION['user'];
    ?>
    <marquee>
      <h1>Bem Vindo <?php echo $utilizadorAtual?>!!</h1>
    </marquee>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
      <p>
        <label for="notaMat">Nota de Matemática:</label>
        <input type="number" name="notaMat" <?php if(isset($_POST['notaMat'])) echo "value=".$_POST['notaMat'];?>>
      </p>
      <p>
        <label for="notaTic">Nota de TIC:</label>
        <input type="number" name="notaTic" <?php if(isset($_POST['notaTic'])) echo "value=".$_POST['notaTic'];?>>
      </p>
      <p>
        <input type="submit" name="calcular" value="Calcular">
      </p>
    </form>
    <?php
    if (isset($_POST['calcular'])) {
      if($_POST['notaMat']!=''&&$_POST['notaTic']!=''){
        if ($_POST['notaMat']>=0 && $_POST['notaMat']<=20 && $_POST['notaTic']>=0 && $_POST['notaTic']<=20) {
          include "functions.php";
          $notaMat=$_POST['notaMat'];
          $notaTic=$_POST['notaTic'];
          $media=calcularMedia($notaMat, $notaTic);
          echo "O $utilizadorAtual tem $notaMat a matemática e $notaTic a TIC, a sua média é $media!";
          
        }
        else {
          echo "Insira valores válidos! (Nota varia de 0 a 20)";
        }
      }
      else {
        echo "Preencha todos os campos!";
      }
    }
    ?>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
      <input type="submit" name="terminarSessao" value="Terminar Sessão">
    </form>
    <?php
    if (isset($_POST['terminarSessao'])) {
      session_destroy();
      header('location:login.php');
    }
    ?>
    <?php
  }
  else {
    header('location:login.php');
  }
  ?>
</body>
</html>
