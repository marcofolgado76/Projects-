<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login Teste Avaliação</title>
</head>
<body style="text-align:center;background-color:gray;">
  <h1>Iniciar Sessão</h1>
  <h3>Área Restrita</h3>
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
    <label for="user">Utilizador:</label>
    <select name="user">
      <option value="lucas" <?php if(isset($_POST['user']) && $_POST['user']=='lucas') echo "selected";?>>Lucas</option>
      <option value="pedro" <?php if(isset($_POST['user']) && $_POST['user']=='pedro') echo "selected";?>>Pedro</option>
      <option value="luis" <?php if(isset($_POST['user']) && $_POST['user']=='luis') echo "selected";?>>Luis</option>
    </select>
  </p>
  <p>
    <label for="pw">Palavra-Passe:</label>
    <input type="password" name="pw">
  </p>
  <p>
    <input type="submit" name="login" value="Iniciar Sessão">
  </p>
</form>
<?php
if (isset($_POST['login'])) {
  if ($_POST['user']!="" && $_POST['pw']!="") {
    include "functions.php";
    $user=$_POST['user'];
    $pw=$_POST['pw'];
    if (iniciarSessao($user,$pw)==true) {
      header('location:index.php');
    }
    else {
      echo "Insira dados Válidos para iniciar Sessão!";
    }
  }
  else {
    echo "Preencha todos os campos!";
  }
}
?>
</body>
</html>
