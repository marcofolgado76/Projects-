<?php  
		function mostrarForm() 
		{
?>
			<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
			    <p> Número Inicial <input type="number" name="inicio" placeholder="Numero Inicio" <?php if (isset($_POST['inicio'])) echo 'value = \'' . $_POST['inicio'] . '\'' ?>></p>
			    <p> Número Final <input type="number" name="fim" placeholder="Numero Fim" <?php if (isset($_POST['fim'])) echo 'value = \'' . $_POST['fim'] . '\'' ?>></p>
			    <input type="submit" name="submit" value="OK">
		 	</form>
		<?php  
		}

		function criarArray (numeroum,numerodois)
		{
			$numeros = range($numeroum, $numerodois); 
			return $numeros ;
		}

		function mostrarImpares ($matriz)
		{
			foreach ($matriz as $key ) {
				if (key % 2 != 0 ) {
					echo $key . ",";
				}
			}
		}
		?>

