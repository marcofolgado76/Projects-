<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    
    <?php 
    	include "funcoes.php";
    	mostrarForm(); 

     ?>

    <?php
    if(isset($_POST['submit'])){
      if(isset($_POST['inicio'])==""||($_POST['fim'])==""){ //testa se os campos estão preenchidos
       echo "Prencha os Campos";
      }
    }
      else{ //caso estejam preenchidos
      ?>
<br>
<br>
      <?php
      if(isset($_POST["inicio"]))$inicio=$_POST['inicio']; //vais buscar os Valores
      if(isset($_POST["fim"]))$fim=$_POST['fim']; //vai Buscar os Valores
      echo "Numero Inicio: ".$inicio?>
      <br>
      <?php echo "Numero Fim: ".$fim;
?>
<br>
<?php
  $valorinicial = $_POST['inicio'];
  $valorfinal = $_POST['fim'];
  mostrarImpares(criarArray ($valorinicial,$valorfinal))
  
?>
  </body>
</html>