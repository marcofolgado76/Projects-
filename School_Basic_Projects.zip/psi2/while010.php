<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
<?php 

	$i= 0;
	while ( $i <= 10)
	{	

		echo "O numero é:". $i . "<br>";
		$i++;
	
	}
 ?>
</body>
</html>