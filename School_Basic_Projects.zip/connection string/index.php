<!DOCTYPE html>
<html>
<head>
	<title>Connectio string</title>
</head>
<body>
<?php
	$nomeserver = "localhost";
	$nomedeutilizador= "marco";
	$senha = "123";
	$nomebd ="bdtestephp";

	$conec = new mysqli($nomeserver, $nomedeutilizador,$senha,$nomebd);

	if ($conec ->connect_error) {
		die("Falhou a conecção :" . $conec ->connect_error);
	}
	$sql = "INSERT INTO  utilizadores (nome,password)
	Values ('Manuel','321');";

	if ($conec -> query ($sql) === TRUE) {
		echo "Utilizador criado com sucesso";
	}
	else {
		echo "Erro:" . $sql . "<br>" . $conec -> error;
	}
		echo	"<tr>";echo	"<th>id</th>";
		echo	"<th>nome</th>";
		echo	"<th>password</th>";
		echo	"</tr>";
		$sql =	"SELECT	*	FROM	utilizadores;";
		$result	=	$conec->query($sql);
		if	($result->num_rows >	0)	{
		while($row	=	$result->fetch_assoc())	 {
		echo	"<tr><td>"	.	$row["id"].	"</td><td>"	.	$row["nome"]	.	"</td></tr>";
			}
		}
		else	{
		echo	"0	results";
		}
		echo("</table>");
	$conec-> close();
?>

</body>
</html>
