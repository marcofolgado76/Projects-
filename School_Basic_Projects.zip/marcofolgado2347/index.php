<?php
	session_start();
	ob_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login teste de avaliação</title>
  </head>
  <body>
        <h3 class="center">Inicio de Sessão</h3>
    <form action="processa.php" method="post">
							<select name="login">
							  <option value="Lucas">Lucas</option>
							  <option value="Pedro">Pedro</option>
							  <option value="Luis">Luis</option>
							</select>
							<br>
            </div>
							<br>
            <label>Senha<input type="password" name="senha" <?php if (isset($_POST['senha'])) echo 'value = \'' . $_POST['senha'] . '\'' ?>></label>
            </div>
            </div>
          </div>
          </div>
      <div>
				<br>
        <button type="submit" name="enviar">Iniciar Sessão</button>
      </div>
    </form>
  </body>
</html>
