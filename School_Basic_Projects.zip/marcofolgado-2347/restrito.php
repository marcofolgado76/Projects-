<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acesso restrito</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js"></script>
</head>
<body>
  <div id="caixa" style="margin-top: 2% ">
      <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
      <div class="row">
      <div class="col s12">
      <div class="col s6">
       <h1>Bem Vindo <?php echo $_SESSION['login']?> !</h1>
       <br>
      <input type="number" placeholder="Matematica " name="mat" min="0" max="20" required></input>
      <br>
      <input type="number" placeholder="tic " name="tic" min="0" max="20" required> </input>
      <br>
      <input type="submit" name="submeter"></input>
        <br>
        <div>
          <button type="submit" name="terminar">Terminar Sessão</button>
        </div>
        </div>
        </div>
        </div>
      </form>
  </div>
  <?php
  	if (isset($_POST['submeter'])) {
  		include "processa.php";
          $mat=$_POST['mat'];
          $tic=$_POST['tic'];
          $media=calcularmedia($mat, $tic);
          echo "O ". $_SESSION['login']." tem " . $mat . " a matemática e " . $tic . " a TIC, a sua média é ". $media ;
  	}
  		
  ?>
</body>
</html>
