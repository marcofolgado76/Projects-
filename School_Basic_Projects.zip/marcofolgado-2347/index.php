<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login teste de avaliação</title>
  </head>
  <body>
      <div class="row">
      <div class="col s12">
      <div class="col s6">
        <h3 class="center">Inicio de Sessão</h3>
    	<form action="processa.php" method="post">
			<select name="login">
				<option value="Lucas">Lucas</option>
				<option value="Pedro">Pedro</option>
				<option value="Luis">Luis</option>
				</select>
			<br>
            </div>
			<br>
            <label>Senha<input type="password" name="senha" <?php if (isset($_POST['senha'])) echo 'value = \'' . $_POST['senha'] . '\'' ?>></label>
            </div>
            </div>
          </div>
          </div>
        <div>
		<br>
        <button type="submit" name="enviar">Iniciar Sessão</button>
      </div>
      </div>
      </div>
      </div>
    </form>
  </body>
</html>
