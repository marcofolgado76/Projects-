<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    session_start();
    ob_start();
    include "functions.php";
      if (isset($_SESSION['log'])) {
        ?>
        <h1>Acesso Restrito!</h1>
        <h2>Seja muito Bem Vindo <?php echo $_SESSION['user']?> !!</h2>
        <div class="container-fluid">
        <div class="row">
        <div class="col-md-4"/>
    
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
          <p>
            <label for="numero">Insira o número:</label>
            <input type="number" name="numero" <?php if(isset($_POST['numero'])) echo 'value=\''.$_POST['numero'].'\''; ?>>
          </p>
          <p>
            <label for="acao">Escolha a operação:</label>
            <select name="acao">
             <option value="quadrado" <?php if(isset($_POST['acao'])){if($_POST['acao']=='quadrado')echo "selected";}?>>Quadrado</option>
             <option value="fatorial" <?php if(isset($_POST['acao'])){if($_POST['acao']=='fatorial')echo "selected";}?>>Fatorial</option>
             <option value="raiz" <?php if(isset($_POST['acao'])){if($_POST['acao']=='raiz')echo "selected";}?>>Raiz Quadrada</option>
            </select>
          </p>
          <p>
            <input type="submit" name="ok">
          </p>
        </form>
        </div>
        </div>
        <?php
      }
      else {
        header("location:login.php");
      }
      if (isset($_POST['ok'])) {
        if ($_POST['numero']!=""&&isset($_POST['acao'])) {
          if ($_POST['acao']=="quadrado") {
          ?>
          <div style='background-color:green; border:5px dotted black; text-align:center'>
            <h1>
              <?php
                echo quadrado($_POST['numero']);
              ?>
            </h1>
          </div>
          <?php
          }
          else if ($_POST['acao']=="fatorial") {
            ?>
            <div style='background-color:green;border:5px dotted black; text-align:center'>
              <h1>
                <?php
                  echo fatorial($_POST['numero']);
                ?>
              </h1>
            </div>
            <?php
          }
          else if ($_POST['acao']=="raiz") {
            ?>
            <div style='background-color:red; border:5px SOLID black; text-align:center'>
              <h1>
                <?php
                  echo raiz($_POST['numero']);
                ?>
              </h1>
            </div>
            <?php
          }
        }
      }
    ?>
    <form method="post" action="functions.php">
      <p>
        <input type="submit" name="terminar" value="Terminar Sessão">
      </p>
    </form>

  </body>
</html>
