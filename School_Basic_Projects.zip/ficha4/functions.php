<?php
  if (isset($_POST['login'])) {
    if ($_POST['user']!=""&&$_POST['pw']!="") {
      session_start();
      ob_start();
      iniciarsessao($_POST['user'], $_POST['pw']);
    }
    else {
      header("location:login.php");
    }
  }
  function iniciarsessao($user,$pw){
    if (trim($user)=="admin"&&$pw=="123") {
      $_SESSION['user']=$user;
      $_SESSION['log']=true;
      header("location:restrito.php");
    }
    else {
      header("location:login.php");
    }
  }
  function quadrado($numero){
    return $resul=$numero*$numero;
  }
  function fatorial($n){
  if ($n === 0) { 
     return 1;
  }
  else {
     return $nr= $n * fact($n-1); 
  }

  }
  function raiz($numero){
    return sqrt($numero);
  }
  if (isset($_POST['terminar'])) {
    session_start();
    ob_start();
    terminarSessao();
    header("location:login.php");
  }
  function terminarSessao(){
    if (isset($_POST['terminar'])) {
      unset($_SESSION['utilizador']);
      unset($_SESSION['logado']);
      session_destroy();
    }
  }
?>
