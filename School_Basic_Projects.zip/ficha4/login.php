<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </head>
  <body>
    <h1>Formulário de Autenticação</h1>
    <div class="container-fluid">
    <div class="row">
    <div class="col-md-4"/>
    <form method="post" action="functions.php">
      <p>
        <label for="user">Utilizador</label>
        <input type="text" name="user">
      </p>
      <p>
        <label for="pw">Palavra-Chave</label>
        <input type="password" name="pw">
      </p>
      <p>
        <input type="submit" name="login" value="Iniciar Sessão">
      </p>
    </form>
    </div>
    </div>
  </body>
</html>


