<?php  
function mostrarform()

{
	?>
<form>
	<div class="col-md-4">
	    <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
      <p><strong>Nome </strong><input type="text" placeholder="Nome" name="name" <?php if (isset($_POST['name'])) echo 'value = \'' . $_POST['name'] . '\'' ?>/></p>
      <p><strong>Idade </strong><input type="number" placeholder="Idade" name="idade" <?php if (isset($_POST['idade'])) echo 'value = \'' . $_POST['idade'] . '\'' ?>/></p>
      <p><strong>País </strong><input type="text" placeholder="País" name="pais" <?php if (isset($_POST['pais'])) echo 'value = \'' . $_POST['pais'] . '\'' ?>/></p>
      <p><strong>Telemóvel </strong><input type="text" placeholder="Telemóvel" name="telemovel" <?php if (isset($_POST['telemovel'])) echo 'value = \'' . $_POST['telemovel'] . '\'' ?>/></p>
      <p><strong>Email </strong><input type="email" placeholder="Email" name="email" <?php if (isset($_POST['email'])) echo 'value = \'' . $_POST['email'] . '\'' ?>/></p>
      <p><input type="submit" name="submit" value="Enviar"/></p>
      </div>
</form>
<?php  
}

 function processa()

{
	?>
	<form>
      <?php         if(isset($_POST['submit'])){
           if(isset($_POST['name'])==""||($_POST['idade'])==""||($_POST['pais'])==""||($_POST['telemovel'])==""||($_POST['email'])==""){
            echo "Prencha os Campos";
           }
           else
           {
           	echo "Bom dia" . $_POST ['name'] . " você tem". $_POST['idade'] . " Mora em" . $_POST['pais'] . " o seu numero é " . $_POST['telemovel'] . " o seu email é " .  $_POST['email'];
           }
                  }
      ?>  
    </form>
  <?php  

    }
     ?>